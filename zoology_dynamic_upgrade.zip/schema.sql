create table if not exists materials(
 id bigint generated always as identity primary key,
 title text,url text,shelf text,topic text,
 status text default 'pending',created_at timestamptz default now());
alter table materials enable row level security;
create policy "read approved" on materials for select using(status='approved');
create policy "insert" on materials for insert with check(true);
